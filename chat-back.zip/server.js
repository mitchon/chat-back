const express = require('express'); //подключение модуля express
const app = express(); //создание web-приложения
const server = require('http').Server(app); //создание http-сервера для работы с приложением
const io = require('socket.io')(server); //подключение модуля socket.io к http-серверу
const mysql = require("mysql2"); //подключение mysql2

io.on('connection', (socket) => {

    socket.on('LOGIN', ({login, password}) => {
        connection.query(('SELECT * FROM users WHERE BINARY login = "' + login + '" AND BINARY password = "' + password + '"'),
            (err, results) => {
                const user = results;
                
                if (user[0] != null)
                {
                    socket.emit('LOG:SUCC', user[0]);
                    socket.login = login;
                    socket.join(user[0].user_id);
                }
                else
                {
                    socket.emit('LOG:UNSUC');
                }

        });
    }); 

    socket.on('REG', (data) => {
        connection.query(('SELECT * FROM users WHERE BINARY login = ?'), data.login,
            (err, results) => {
                const user = results;
                
                if (user[0] != null)
                {
                    socket.emit('REG:UNSUC');
                }
                else
                {
                    connection.query(('INSERT INTO users (login, password) VALUES (?, ?)'), [data.login, data.password],
                        () => {
                        socket.emit('REG:SUCC');
                    });
                }

        });
    });

    socket.on('EDIT', (data) => {
        connection.query(('SELECT * FROM users WHERE user_id = ? AND BINARY password = ?'), [data.user_id, data.oldPassword],
            (err, results) => {
                const user = results;
                
                if (user[0] != null)
                {
                    console.log(data);
                    connection.query(('UPDATE users SET login = ?, password = ?  WHERE user_id = ?'), [data.login, data.password, data.user_id]);
                    const u = data.login;
                    socket.emit('EDIT:SUCC', u);
                }
                else
                {
                    socket.emit('EDIT:UNSUC');
                }

        });
    });

    socket.on('USER:FIND', (search) => {
        connection.query(('SELECT * FROM users WHERE login = ?'), search,
            (err, results) => {
                const user = results;
                
                if (user[0] != null)
                {
                    socket.emit('USER:FOUND', user);
                }
            });
    });

    socket.on('USER:FRIENDS', (search) => {
        connection.query(('SELECT user_id, login, image FROM friends INNER JOIN users ON user2=user_id WHERE user1 = ? UNION SELECT user_id, login, image FROM friends INNER JOIN users ON user_id=user1 WHERE user2 = ?'), [search, search],
            (err, results) => {
                const users = results;
                
                if (users[0] != null)
                {
                    socket.emit('USER:FOUNDFRIENDS', users);
                }
            });
    });

    socket.on('DIALOG:FIND', (search) => {
        connection.query(('SELECT * FROM messages WHERE sender = ? OR receiver = ?'), [search, search],
            (err, results) => {
                const messages = results;
                
                if (messages[0] != null)
                {
                    socket.emit('DIALOG:FOUND', messages);
                }
            });
    });

    socket.on('MESSAGE:SEND', (data) => {
        connection.query(('INSERT INTO messages (value, sender, receiver) VALUES (?, ?, ?)'), data);
        const obj = {
            value: data[0],
            sender: data[1],
        };
        socket.to(data[2]).emit('NEW:MESSAGE', obj);
    });

    socket.on('NEW:FRIEND', (data) => {
        console.log(111);
        connection.query(('INSERT INTO friends (user1, user2) VALUES (?, ?)'), data);
        connection.query(('select users.* from friends  inner join users on user2=user_id where (user1 = ? and user2 = ?) union select users.* from friends  inner join users on user1=user_id where (user1 = ? and user2 = ?);'), [data[1], data[0], data[0], data[1]],
            (err, results) => {
                const user = results;
                if (user != null)
                {
                    socket.to(data[1]).emit('USER:FOUNDNEWFRIEND', user[0]);
                }
            });
    });

    socket.on('disconnect', () => {
        console.log(socket.id, "disconnected");
    });

    console.log('socket connected', socket.id);
});

server.listen(8888, (err) => {
    if (err) {
        throw Error(err);
    }
    console.log('Started');
});
  
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "Messenger_db",
  password: "root"
});
// тестирование подключения
 connection.connect(function(err){
    if (err) {
      return console.error("Ошибка: " + err.message);
    }
    else{
      console.log("Подключение к серверу MySQL успешно установлено");
    }
 });